//
//  AppDelegate.h
//  Speedboy
//
//  Created by TaHoangMinh on 10/12/15.
//  Copyright © 2015 TaHoangMinh. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kAdmod @"ca-app-pub-6404264627814552/8002312023"
#define kAdmodInterestial @"ca-app-pub-6404264627814552/9479045226"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

