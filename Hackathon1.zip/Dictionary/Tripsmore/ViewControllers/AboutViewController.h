//
//  AboutViewController.h
//  Speedboy
//
//  Created by TaHoangMinh on 2/11/16.
//  Copyright © 2016 TaHoangMinh. All rights reserved.
//

#import "BasedTableViewController.h"

@interface AboutViewController : BasedTableViewController

@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end
