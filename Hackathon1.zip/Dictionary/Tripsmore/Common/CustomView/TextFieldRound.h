//
//  TextFieldRound.h
//  Speedboy
//
//  Created by TaHoangMinh on 10/13/15.
//  Copyright © 2015 TaHoangMinh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextFieldRound : UITextField

@property UIView *viewBackground;

@end
