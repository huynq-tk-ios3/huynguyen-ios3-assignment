//
//  TextFieldCustom.h
//  Speedboy
//
//  Created by Minh Ta Hoang on 8/18/15.
//  Copyright (c) 2015 Ta Hoang Minh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextFieldCustom : UITextField

@property NSString *strValueSuggession;
@property UILabel *lblValueSugession;

@end
