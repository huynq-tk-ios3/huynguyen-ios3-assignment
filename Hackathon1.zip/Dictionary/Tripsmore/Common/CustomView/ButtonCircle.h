//
//  ButtonRoundCorner.h
//  Speedboy
//
//  Created by Minh Ta Hoang on 6/29/15.
//  Copyright (c) 2015 Ta Hoang Minh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ButtonCircle : UIButton

@end
