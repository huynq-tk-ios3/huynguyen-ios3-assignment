//
//  UIScrollView+FSExtension.h
//  Pods
//
//  Created by Wenchao Ding on 5/3/15.
//
//

#import <UIKit/UIKit.h>

@interface UIScrollView (FSExtension)

- (void)fs_scrollBy:(CGPoint)offset animate:(BOOL)animate;

@end
// Copyright belongs to original author
// http://code4app.net (en) http://code4app.com (cn)
// From the most professional code share website: Code4App.net