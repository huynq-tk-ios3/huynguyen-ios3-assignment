//
//  UITextInputScrollViewController.m
//  Fotola
//
//  Created on 11/14/13.
//  Copyright (c) 2013 Home. All rights reserved.
//

#import "BasedTextInputScrollViewController.h"
@interface BasedTextInputScrollViewController () {
    UITapGestureRecognizer * tapGesture;
}

@end

@implementation BasedTextInputScrollViewController


@end
