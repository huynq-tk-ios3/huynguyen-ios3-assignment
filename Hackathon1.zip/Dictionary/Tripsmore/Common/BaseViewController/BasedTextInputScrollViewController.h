//
//  UITextInputScrollViewController.h
//  Fotola
//
//  Created on 11/14/13.
//  Copyright (c) 2013 Home. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BasedViewController.h"
@interface BasedTextInputScrollViewController : BasedViewController <UITextFieldDelegate, UITextViewDelegate>


@end

